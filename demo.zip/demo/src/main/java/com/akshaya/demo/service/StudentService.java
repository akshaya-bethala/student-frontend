package com.akshaya.demo.service;

import com.akshaya.demo.model.Student;
import com.akshaya.demo.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    @Autowired
    private StudentRepository repo;

    // GET ALL
    public List<Student> getAllStudents() {
        return repo.findAll();
    }

    // SAVE
    public Student saveStudent(Student student) {
        return repo.save(student);
    }

    // GET BY ID
    public Student getStudentById(Long id) {
        return repo.findById(id).orElse(null);
    }

    // DELETE
    public void deleteStudent(Long id) {
        repo.deleteById(id);
    }

    // UPDATE
    public Student updateStudent(Long id, Student student) {
        Student existing = repo.findById(id).orElse(null);

        if (existing != null) {
            existing.setName(student.getName());
            existing.setEmail(student.getEmail());
            existing.setAge(student.getAge());
            return repo.save(existing);
        }
        return null;
    }
}